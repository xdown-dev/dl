#! /bin/bash

curUser=$USER

installPath='/Library/Application Support/XDown'

chromePath=/Users/${curUser}/Library/Application\ Support/Microsoft\ Edge/

echo ${chromePath}

if [ -d "${installPath}" ]; then
	sudo chown -R "${curUser}" "${installPath}" 
fi

if [ -d "${chromePath}" ]; then
	echo 'copy org.xdown.xmsg.json to chrome path '
	chromeNativeMsgPath=${chromePath}/NativeMessagingHosts/
	if [ -d "${chromeNativeMsgPath}" ]; then
		cp -rf "${installPath}/org.xdown.xmsg.json"  "${chromeNativeMsgPath}"
		sudo chown -R "${curUser}" "${chromeNativeMsgPath}/org.xdown.xmsg.json"
	fi 

	chromeExtensionPath=${chromePath}/External\ Extensions/
	if [ ! -d "${chromeExtensionPath}" ]; then
		mkdir -p "${chromeExtensionPath}"
		sudo chown -R "${curUser}" "${chromeExtensionPath}" 
	fi
	echo 'copy eapmjcdkdlenhkbanlgacimfibbbiinc.json to chrome native msg path path '
	cp -rf "${installPath}/eapmjcdkdlenhkbanlgacimfibbbiinc.json"  "${chromeExtensionPath}"
	sudo chown -R "${curUser}" "${chromeExtensionPath}/eapmjcdkdlenhkbanlgacimfibbbiinc.json"
fi


echo 'post install xdown ok...'

